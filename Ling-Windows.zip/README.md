# Ling Windows v1.0

小灵是 Windows 桌面动画伙伴，有银色和红心白帽两套造型。支持 Windows 10 x64 或更新版本。完整解压本 ZIP，保留整个 `Ling` 文件夹，然后双击 `Ling/Ling.exe`。不需要安装 Python、ChatGPT 或 Codex。

鼠标悬停可跳跃，单击可挥手，拖动可移动。右键点击小灵或托盘图标，可以换装、暂停、选择动作和退出。服装选择会保存到本机设置。

原创程序代码、素材和安装脚本分别适用 `LICENSE-CODE.md`、`LICENSE-ART.md` 和 `LICENSE-SCRIPTS`；第三方软件见 `THIRD-PARTY-NOTICES.md`、`MICROSOFT-TERMS.md` 与 `licenses/`。

项目主页：[Ling with me](https://github.com/Saguinusimperator/ling-with-me)。
